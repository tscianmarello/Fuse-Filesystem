#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>

//In order to run this program you must have fuse installed. 
//Call sudo apt update and then sudo apt install fuse to install FUSE.
//Then to compile and mount the program call:
//gcc filesystem.c -o filesystem `pkg-config fuse --cflags --libs`
//This will produce a file called filesystem.
//Then simply mount it:
//	./filesystem -f <mount location>

//These are the arrays that store the filesystem. They are currently 100x100 arrays. This means that they can store 100 directories/files of 100 
//bytes each. The values can be modified. 
char directoryArr[100][512];
char fileArr[100][512];
char contentArr[100][100];

//These are the indices to iterate and store in the array. They are initialized at -1 and then incremented.
int directoryIndex = -1;
int fileIndex = -1;
int contentIndex = -1;

//These are the symbols used to call current and parent. Example: cd ..
char currDirectory =  '.';
char parentDirectory[2] = "..";

//Function that checks if the directory is empty, and if it is not empty, compares if the directory name has already been added to the directory.
bool checkDirectory(const char *checkName)
{
	//if -1 then returns false because array is empty.
        if(directoryIndex == -1)
        {
                return false;
        }
	//Otherwise, it iterates from 0 to the directory index, checking if the array was added to the list. 
        for(int i = 0; i <= directoryIndex; i++)
        {
                if(strcmp(checkName, directoryArr[i]) == 0)
                {
                        return true;
                }
        }
	//return false if the directory is not in the array.
        return false;
}

//Function that checks if the file is empty, and if it is not empty, then it compares if the file is in the array. 
bool checkFile(const char *checkName)
{
	//if -1 then returns false because file array is empty.
        if(fileIndex == -1)
        {
                return false;
        }
	//Otherwise, iterates from 0 to directory index to check if file is in the array.
        for(int i = 0; i <= fileIndex; i++)
        {
                if(strcmp(checkName, fileArr[i]) == 0)
                {
                        return true;
                }
        }
	//return false if file is not in array.
        return false;
}

//Checks content of file. 
bool checkContent(const char *checkName)
{
	//if -1, then content is not in the content array.
        if(contentIndex == -1)
        {
                return false;
        }
	//Otherwise iterates and checks if the content has been added to the array.
        for(int i = 0; i <= contentIndex; i++)
        {
                if(strcmp(checkName, contentArr[i]) == 0)
                {
                        return true;
                }
        }
	//Returns false if the content is not in the array.
        return false;
}

//Function that adds directory to the directory array.
void addDirectory(const char *directoryName)
{
	//Variable that checks if the directory exists in the directory array or if the directory array has not been initialized.
 	bool check = checkDirectory(directoryName);
	//If the file is not a duplicate and the array has been initialized.
	if(!check)
	{
		//Then increase the directory index to allow the directory name to be copied to the directory array.	
		directoryIndex++;
		strcpy(directoryArr[directoryIndex],  directoryName);
	}
}

//Function that adds file to file array.
void addFile(const char *fileName)
{
	//Variable that checks if the file exists in the file array or if the file array has not been initialized.
	bool check = checkFile(fileName);
	//If the file is not a duplicate and the array has been initialized.
	if(!check)
	{
		//Then increase the directory index to allow the file name to be copied to the file array.
		fileIndex++;
		strcpy(fileArr[fileIndex], fileName);
	}
}

//Function that locates the index of the directory in the directory array.
int findDirIndex(const char *location)
{
	//Increase the location.
	location++;
	//Check if the directory name exists in the directory array.
	bool check = checkDirectory(location);
	//If it does then iterate through array to find the directory and return the index.
	if(check)
	{
		for(int i = 0; i <= directoryIndex; i++)
		{
			if(strcmp(location, directoryArr[i]) == 0)
			{
				return i;
			}
		}
	}
	return 0;
}

//Function that locates the index of the file in the file array.
int findFileIndex(const char *location)
{
	//Increase the location.
	location++;
	//Check if the file name exists in the file array.
	bool check = checkFile(location);
	//If it does then iterate through the entire array to find the file and return the index.
	if(check)
	{
		for(int i = 0; i < fileIndex; i++)
		{
			if(strcmp(location, fileArr[i]) == 0)
			{
				return i;
			}
		}
	}
	return 0;
}

//Function for get attributes that is mandatory from FUSE. Takes the user ID, group ID and assigns privileges based on whether the object is a 
//file or array
static int file_getattr(const char *location, struct stat *statbuffer)
{
	//Assigns user ID and group ID.
	statbuffer->st_uid = getuid();
	statbuffer->st_gid = getgid();
	//Checks if directory and folder arrays contain the folder or directory.
	bool dirCheck = checkDirectory(location);
	bool fileCheck = checkFile(location);
	//Checks if object is a directory
	if((strcmp(location, "/") == 0) || dirCheck)
	{
		//Assign n-links and privileges.
		statbuffer -> st_mode =  S_IFDIR|744;
		statbuffer -> st_nlink = 2;
	}
	//Checks if object is a file
	else if(fileCheck)
	{	//Assigns n-link, size of file, and privileges.
		statbuffer -> st_mode = S_IFREG|744;
		statbuffer -> st_nlink = 1;
		statbuffer -> st_size = 256;
	}
	//Otherwise returns error.
	else
	{
		return -ENOENT;
	}
	return 0;
}

//Function that reads directory.
static int file_readdir(const char *location, void *fillFile, fuse_fill_dir_t fillBuffer, off_t diff, struct fuse_file_info *info)
{
	//Checks if directory is not empty
	if(directoryIndex != -1)
	{
		//Checks if in current directory or parent directory.
		fillBuffer(fillFile, ".", NULL, 0);
		fillBuffer(fillFile, "..", NULL, 0);
	}

	return 0;
}

//Function that reads in the folder
static int file_read(const char *location, char *buf, size_t size, off_t diff, struct fuse_file_info *info)
{

	char firstFile[24] = "First file of FileSystem";
	char secondFile[25] = "Second file of FileSystem";
	char thirdFile[24] = "Third file of FileSystem";
	char fourthFile[24] = "Fourth file of FileSystem";
	char *fileSelected = NULL;
	//Check if there are any files added to fileArr by checking index.
	if(fileIndex != -1)
	{
		//Check if the first file has been added.
		if(strcmp(location, "/firstFile") == 0)
		{
			fileSelected = firstFile;
		}
		//Check if second file has been added instead.
		else if(strcmp(location, "/secondFile") == 0)
		{
			fileSelected = secondFile;
		}
		else if(strcmp(location, "/thirdFile") == 0)
		{
			fileSelected = thirdFile;
		}
		else if(strcmp(location, "/fourthFile") == 0)
		{
			fileSelected = fourthFile;
		}
		//Otherwise no file has been added.
		else
		{
			return -1;

		}
	}
}

//Struct that contains the fuse operations
static struct fuse_operations operations = {
	.getattr = file_getattr,
	.readdir = file_readdir,
	.read = file_read,
};

int main(int argc, char *argv[])
{
	//Initialize the Fuse operations in main.
	return fuse_main(argc, argv, &operations, NULL);
}
